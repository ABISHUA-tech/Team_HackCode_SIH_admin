async function loadComplaints() {
  try {
    const res = await fetch(
      "https://script.google.com/macros/s/AKfycbxtYLyDnhYZS8zeee2xRoYVndVhAYM0x_uJwaUq2RRd4fhuMFvGBNaIZu6wz-CFA2O6/exec"
    );
    const data = await res.json();

    const tableBody = document.querySelector("#complaintsTable tbody");
    tableBody.innerHTML = "";

    // Skip first row (headers from Google Sheet)
    data.slice(1).forEach((row) => {
      const [name, email, complaint, timestamp] = row;
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${name}</td>
        <td>${email}</td>
        <td>${complaint}</td>
        <td>${timestamp}</td>
      `;
      tableBody.appendChild(tr);
    });
  } catch (err) {
    console.error("Error fetching complaints:", err);
  }
}

loadComplaints();
setInterval(loadComplaints, 10000); // auto-refresh every 10s